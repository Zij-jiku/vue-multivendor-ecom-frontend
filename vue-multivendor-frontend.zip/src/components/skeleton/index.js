export { default as SliderSkeleton } from "./SliderSkeleton.vue";
export { default as CategorySkeleton } from "./CategorySkeleton.vue";
export { default as ProductSkeleton } from "./ProductSkeleton.vue";
