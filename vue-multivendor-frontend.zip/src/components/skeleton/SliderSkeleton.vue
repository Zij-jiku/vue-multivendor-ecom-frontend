<template>
    <div>
        <img src="@/assets/images/slider/slider.jpg" alt="loading-slider" />
        <div class="ssc-line w-100"></div>
    </div>
</template>