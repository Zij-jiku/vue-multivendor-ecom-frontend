export {default as Index } from './Index.vue';
export {default as Shop } from './Shop.vue';
export {default as SingleProduct } from './SingleProduct.vue';
export {default as CheckoutPage } from './CheckoutPage.vue';
