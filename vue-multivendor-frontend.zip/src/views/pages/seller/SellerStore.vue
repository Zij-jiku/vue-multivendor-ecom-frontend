<template>
    <div>
        <section class="single-banner" style="
          background: url('//website/images/single-banner.jpg') center center
            no-repeat;
        ">
            <div class="container">
                <h2>Seller Products</h2>
            </div>
        </section>
        <div class="brand-single">
            <a href="#">
                <div>
                    <img src="http://127.0.0.1:8000/uploads/seller/shop/07022022032357LeHFrk4a5SWRJcDf_250_250.jpg"
                        alt="product" />
                </div>
            </a><a href="#">
                <h3>Uc Techonology</h3>
            </a>

        </div>
        <section class="inner-section shop-part">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="top-filter">
                            <div class="filter-show">
                                <label class="filter-label">Show :</label><select class="form-select filter-select">
                                    <option value="10">10</option>
                                    <option value="20">20</option>
                                    <option value="30">30</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                            <div class="filter-short">
                                <label class="filter-label">Short by :</label><select class="form-select filter-select">
                                    <option value="">default</option>
                                    <option value="new">New</option>
                                    <option value="popular">Popular</option>
                                    <!-- <option value="winter">Winter</option> -->
                                    <option value="feature">Feature</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row row-cols-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-5">
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label><label class="view-label off">-5%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/laptop-charger-65w" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022020249MjpDqMftIgtCoPSp_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/laptop-charger-65w" class="">Laptop Charger 65W</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳1,300</del><span>৳1235</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label><label class="view-label off">-10%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/core-i3-12100-12th-gen-pc" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022020021EeHb46up8zbmsiY7_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/core-i3-12100-12th-gen-pc" class="">Core i3 12100 12th Gen PC</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳37,000</del><span>৳33300</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">popular</label><label
                                        class="view-label off">-10%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/canon-eos-250d-241mp-full-hd-dslr-camera" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022015502jgDmrhSiM8HFFLh1_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/canon-eos-250d-241mp-full-hd-dslr-camera" class="">CANON EOS 250D
                                        24.1MP Full HD DSLR Camera</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳63,000</del><span>৳56700</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label>
                                    <!--v-if-->
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/canon-eos-200d-dsl-camera" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022015117B0tRXhS875u7frRy_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/canon-eos-200d-dsl-camera" class="">Canon Eos 200D Dsl Camera</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <!-- {{ $filters.currencyBDT(product.price) }} --><span>৳45,600</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label><label class="view-label off">-5%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/gopro-hero-10-black" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022012816J1zbdk9D3Zjcw1Xk_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/gopro-hero-10-black" class="">Gopro Hero 10 Black</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳43,500</del><span>৳41325</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label>
                                    <!--v-if-->
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/gaming-headphone" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022011920tOaFVDgQNhdAMJMB_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/gaming-headphone" class="">Gaming Headphone</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <!-- {{ $filters.currencyBDT(product.price) }} --><span>৳1,300</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">popular</label>
                                    <!--v-if-->
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/rgb-gaming-caching" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022010620djSwp57SVPSgww0E_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/rgb-gaming-caching" class="">Rgb Gaming Caching</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <!-- {{ $filters.currencyBDT(product.price) }} --><span>৳2,500</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card product-disable">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label>
                                    <!--v-if-->
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/case-antec-mid-tower-argb-gaming-case" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/070120220106229trNxb09DLon5KVD_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/case-antec-mid-tower-argb-gaming-case" class="">Case Antec Mid
                                        Tower ARGB Gaming Case</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <!-- {{ $filters.currencyBDT(product.price) }} --><span>৳3,600</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label><label class="view-label off">-10%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/acer-laptop" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022010124LbsRSovAaSuvYsAY_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/acer-laptop" class="">Acer Laptop</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳42,500</del><span>৳38250</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <!-- //disable or stock out products // use class product-disable // after product-card -->
                        <div class="product-card">
                            <div class="product-media">
                                <div class="product-label">
                                    <label class="label-text sale">new</label><label class="view-label off">-5%</label>
                                </div>
                                <div>
                                    <button class="product-wish wish" data-bs-toggle="modal"
                                        data-bs-target="#login-modal">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <a href="/product/mouse" class="product-image">
                                    <div>
                                        <img src="http://127.0.0.1:8000/uploads/seller/products/07012022004704Z9NkHORqMTGwdsMN_450_450.jpg"
                                            alt="product" />
                                    </div>
                                </a>
                            </div>
                            <div class="product-content">
                                <!-- <div class="product-rating">
            <i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i
            ><i class="active icofont-star"></i><i class="icofont-star"></i
            ><a href="product-video.html">(3)</a>
          </div> -->
                                <h6 class="product-name">
                                    <a href="/product/mouse" class="">Mouse</a>
                                </h6>
                                <div>
                                    <!-- //jodi modal ba single product page theke data ase.. tahole h3 design  -->
                                    <h6 class="product-price">
                                        <del>৳500</del><span>৳475</span>
                                    </h6>
                                </div>
                                <button class="product-add" title="Add to Cart">
                                    <i class="fas fa-shopping-basket"></i><span>Shop Now</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<style>
    @import "@/assets/css/brand-min.css";
</style>