<template>
    <div>
        <section class="inner-section single-banner" style="
          background: url(//website//website/images/single-banner.jpg) no-repeat;
        ">
            <div class="container">
                <h2>Order List</h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">My Orders</a></li>
                </ol>
            </div>
        </section>
        <section class="inner-section wishlist-part">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="table-scroll">
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112640vS6vLlmYFPtRUWhN_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Mens Suglass</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#70035711</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳4,341</span></th>
                                    </tr>
                                    <tr style="display: none">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span style="display: none"> Discount: -৳0</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳4,401</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641ok9feZKytgrXBJx3_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Men's Pant</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#30121190</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳4,328</span></th>
                                    </tr>
                                    <tr style="display: none">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span style="display: none"> Discount: -৳0</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳4,388</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641dIhVFtkcgaaMykXb_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Girls Cloth</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>2</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#25688933</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳1,434</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳500</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳994</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>2</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#76223790</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳7,889</span></th>
                                    </tr>
                                    <tr style="display: none">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span style="display: none"> Discount: -৳0</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳7,949</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641dIhVFtkcgaaMykXb_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Girls Cloth</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>2</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06202022121706yj3SXnXwMSaQBv7p_450_450.png"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Men's Pant</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>3</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112643IngWxgrZYmRUae4U_450_450.png"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Women Watch</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>2</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>4</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>5</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>6</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641ok9feZKytgrXBJx3_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Men's Pant</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#18755045</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳9,733</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳500</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳9,293</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>5</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641ok9feZKytgrXBJx3_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Men's Pant</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>3</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>3</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112641dIhVFtkcgaaMykXb_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Girls Cloth</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>6</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>4</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/070120220216252JsAfaISYOqXxJ1L_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Iphone 12Pro Max</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>3</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>5</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>11</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#71634311</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳49,323</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳9,865</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳39,518</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/070120220216252JsAfaISYOqXxJ1L_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Iphone 12Pro Max</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#49110170</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳4,365</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳873</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳3,552</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>4</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112640vS6vLlmYFPtRUWhN_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Mens Suglass</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#17175247</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳13,806</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳2,761</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳11,105</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>3</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/070120220216252JsAfaISYOqXxJ1L_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Iphone 12Pro Max</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#94644314</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳12,251</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳2,450</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳9,861</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#66480339</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳3,155</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳631</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳2,584</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/070120220216252JsAfaISYOqXxJ1L_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Iphone 12Pro Max</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>3</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>2</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#77467832</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳10,675</span></th>
                                    </tr>
                                    <tr style="display: none">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span style="display: none"> Discount: -৳0</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳106,750</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06032022112643IngWxgrZYmRUae4U_450_450.png"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Women Watch</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06202022121706yj3SXnXwMSaQBv7p_450_450.png"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Men's Pant</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#415</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳1,258</span></th>
                                    </tr>
                                    <tr style="display: none">
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span style="display: none"> Discount: -৳0</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳12,580</span></th>
                                    </tr>
                                </tbody>
                            </table>
                            <table class="table-list">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Order</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>1</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/06112022170911auEgHYNcwX4xjxoo_450_450.jpeg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Et non.</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>2</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/070120220216252JsAfaISYOqXxJ1L_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Iphone 12Pro Max</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>1</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td class="table-serial">
                                            <h6>3</h6>
                                        </td>
                                        <td class="table-image">
                                            <img src="http://127.0.0.1:8000/uploads/products/07012022020842kHZuaIOyr11cYtuO_450_450.jpg"
                                                alt="product" />
                                        </td>
                                        <td class="table-name">
                                            <h6>Yamaha R15 Bike</h6>
                                        </td>
                                        <td class="table-name">
                                            <h6>3</h6>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Order:#2147483647</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Subtotal: ৳13,830</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Discount: -৳500</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span> Delivery Charge: ৳60</span></th>
                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th><span>Total: ৳13,390</span></th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center mt-5">
                            <button class="btn btn-outline">Load more Orders</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</template>