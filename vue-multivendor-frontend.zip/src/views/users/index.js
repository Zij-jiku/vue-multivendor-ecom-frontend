export {default as UserProfile } from './Profile.vue';
export {default as UserOrders } from './MyOrderlist.vue';
export {default as UserWishlist } from './Wishlist.vue';